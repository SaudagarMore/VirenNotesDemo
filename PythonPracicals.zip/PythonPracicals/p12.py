#2)Take an integer N from the user and find the
#sum of first N natural numbers using a while loop.

'''
no=int(input("Enter Any number:"))
sum1=0
no1=1
while no1<=no:#6<=5
    sum1+=no1#15=10+5
    no1+=1#6
print("the addition is:",sum1)

#3
# 5 ->1*2*3*4*5 ->2*3*4*5->6*4*5->24*5->120
fact=1
no=int(input("Enter Any number:"))
for k in range(1,no+1):
    fact=fact*k
    print("Current Number Factorial is:",k," ",fact)

print("Factorial is:",fact)
'''
