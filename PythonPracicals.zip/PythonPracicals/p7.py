#Q1.Take two numbers as input and print their sum, difference,
#product, and division.
# user input
'''
no1=int(input("Enter First no:"))
no2=int(input("Enter Second No:"))
print("--------------------------------")
print("The sum is:",no1+no2)
print("The Substract is:",no1-no2)
print("The Product is:",no1*no2)
print("The division is:",no1/no2)
'''
#Q2.Take two numbers from the user and calculate
#floor division and modulus.
'''
no1=int(input("Enter First no:"))
no2=int(input("Enter Second No:"))
print("--------------------------------")
print("Floor division is:",no1//no2)
print("The modulus is:",no1%no2)
'''
#Q3.Ask the user for base and exponent. Calculate the result using **.
'''
no1=int(input("Enter base no:"))
no2=int(input("Enter exponent No:"))
print("the Result is:",no1**no2)
'''
#Q4.Take two numbers and calculate the average using arithmetic operators.
# + - * / %
'''
num1=int(input("Enter First no:"))
num2=int(input("Enter Second no:"))
avg=(num1+num2)/2 #
print("Average is:",avg)
'''
#Q5.Ask the user to enter the total price and
#number of items, and calculate the price per
#item.
'''
num1=int(input("Enter Total Price:"))
num2=int(input("Enter Numer of Items:"))
print("The Price per item is:",num1/num2)
'''
#Q6.Take two numbers and print whether the first is
#greater than, less than, or equal to the second.
#< > >= <= != ==
'''
num1=int(input("Enter First No:"))
num2=int(input("Enter Second No:"))
print("First is greter than of two:",num1>=num2 and num1==num2)
'''
#Q10.Take a number, add 10 to it using +=, and print the new value.
'''
s=50
print("Old Value:",s)
s+=10
print("new Value:",s)
'''
#Q11.Take a number and double it using *= assignment operator.
'''
s=50
print("Old Value:",s)
s*=2
print("new Value:",s)
'''
#Q12.Ask the user for a value, divide it by 5 using /=, and show the result.
no=int(input("Enter Any numbeR:"))
no/=5
print("After divide is:",no)
#print("After Divide Result:",divide)



