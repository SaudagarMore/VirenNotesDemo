no=40
no1=60
no2=30
no3=5
no4=6
no5=100
no6=5

#+=
print(no," ",no1)
no+=no1# Add and Assign
print(no," ",no1)
print("Before:",no1," ",no2)
no1-=no2 #substract And Assign
print("After:",no1," ",no2)
print("Before:",no3," ",no4)
no3*=no4 #multiply And Assign
print("After:",no3," ",no4)
print("Before:",no5," ",no6)
no5/=no6
print("After :",no5," ",no6)
print("-----------------------------------")
# //= , **=  %=,
m1=20
m2=3
m3=50
m4=5
m5=30
m6=4
print("Before:",m1," ",m2)
m1//=m2
print("After :",m1," ",m2)

print("Before:",m3," ",m4)
m3**=m4
print("After :",m3," ",m4)

print("Before:",m5," ",m6)
m5%=m6
print("After :",m5," ",m6)

