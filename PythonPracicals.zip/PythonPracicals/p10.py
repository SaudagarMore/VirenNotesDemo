'''
#Example Of Only End
for j in range(11):# start =0 end 
    print(j,end=" ")
print("\n")
# Example of Start and End
for j in range(0,21):# start =0 end 
    print(j,end =" ")

#Example of STart ,end ,step
print("\n")
for k in range(1,100,10):
    print(k,end=" ")
'''
'''for i in range(1,6):#outer loop 1 2 3 4 5
    for j in range(1,7):#inner loop 1 2 3 4 5
        print(i,end=" ")# 
    print("\n")
'''
'''
cn=0
odd=0
for m in range(1,21):
    if m%2==0:
        print(m)
        cn+=1
    else:
        odd+=1

print("Total Count of even is:",cn)
print("odd is:",odd)


#fact=1
for p in range(1,6):# 1 2 3 4 5 
    fact=fact*p # 120

print("Factorial is:",fact)

'''
'''
100>5 true/false
range 100>5
for u =0;u<=10;u++:

for u in range(u<=10;u++,-1) 100,99,98,97 ...5)
for u in range(100,5,-5):

for i in range(1,20):
    print(i,end=" ")
print("\n")

for u in range(100,5,-1):# greter than less than
    print(u,end=" ")
'''
'''
a=0 #start //
while a<=20:#condition 0<=20 True
    print(a, end=" ")#0 1 2 3 4 5 .. 20
    a+=1 #0=0+1 ->1
b=120 #max value
while b>=5:#lower b>5 -> 50>5/true/false
    print(b,end=" ")#50,
    b-=1 # 50-=1 ->49,48,47,46,45....... 5
'''
for i  in range (1,11):
    print(5*i)





































      

      
