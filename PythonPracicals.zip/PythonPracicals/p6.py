a=100
b=100
c=50
#30==50
#print(a>b and b<c and b%2==0 and b==c) # 10>30(false) 30<50 (true)

#print(a==b or b>c) #100>30 (false)

name="Rahul Mane"

La=["Apple","Banan","Grapes"]
#La



print('Apple'  in La) # True
