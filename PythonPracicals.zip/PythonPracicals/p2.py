no=int  #static type Strong type
no=100
value=500.30 # float
value="Rohit"
name="Viren More" # '' " " """ """
name1=str # fix type is string

result=True
com=5+9j

print(no)
print(value)
print(name)
print(result)
print(com)

print("The Datatype is:",type(no))
print(type(value))
print(type(name))
print(type(result))
print(type(com))
