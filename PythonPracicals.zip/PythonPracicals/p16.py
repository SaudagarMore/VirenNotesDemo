mydata=[10,20,30,40,50,60,70,80,90]
print(mydata[0::]) #

print(mydata[::-1])
