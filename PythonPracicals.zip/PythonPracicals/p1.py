print("hello")
print("hii")
print (" hii My Name is Viren",end="++")
print(" hello")
'''
() ->rounded
[] ->sqaure
{} ->curly
'''

'''
multiline comment
'''

# hello 
