no=int(input("Enter any No:"))
no1=int(input("Enter Another No:"))

add=no+no1
sub=no-no1
multiply=no*no1
div=no/no1
moddiv=no%no1
floordiv=no//no1
exponent=no**no1
print("------------------------------------")
print("Add is:",{add})
print("Sub is:",{sub})
print("Multiplication is:",multiply)
print("division is:",div)
print("Modulus division is:",moddiv)
print("Floor division is:",floordiv)
print("Exponentialition vlaue is:",exponent)
print("------------------------------------")
print(" Comparison And Relation Operators:")
print("The quality is:",no==no1)
print("Max is:",no>no1)
print("min is:",no<no1)
print("Max eqaul:",no>=no1)
print("Min eqaul :",no<=no1)
print("Not Equality:",no!=no1)























