# Take Input OF Student Sid,sname,fees,course,age,address,subject,class,percetage,gender,result.
# int,float,str,complex,bool

sid=int(input("Enter Student Id:"))
Sname=str(input("Enter Student Name:"))
Fees=int(input("Enter Student Fees:"))
Course=(input("Enter Student Course:"))
Age=int(input("Enter Student Age:"))
Address=str(input("Enter Student Address:"))
Suject=str(input("Enter Student Subject:"))
Class=(input("Enter Student class:")) # 9
Percetage=float(input("Enter Student Percetage:"))
Gender=(input("Enter Student gender:"))
result=bool(input("Enter Result (Boolean Form) [True=pass And false=fail]: "))

print("------------------")
print("Student id is:",sid)
print("Student name is:",Sname)
print("Student Fees is:",Fees)
print("Student Course is:",Course)
print("studnet Age is:",Age)
print("Student Address is:",Address)
print("Student Subject is:",Subject)
print("Student Class is:",Class)
print("Student Percentae:",Percetage)
print("Student Gender is:",Gender)
print("Student Result is:",result)
print("------------------")


'''
a=int(input("Enter The Value:"))
b=input("Enter Your Name:") #str

c=bool(input("Enter Details:")) #str
d=complex(input("Enter Imaginary Data:"))
e=float(input("Enter floating Value:"))

print(b)
print(c)
print(d)
print(e)
a1="ABC"
print(a*a)
'''
#print(a)
'''
no=200
name="UV"
amount=600.30

print(no)
print(name)
print(amount)
'''

