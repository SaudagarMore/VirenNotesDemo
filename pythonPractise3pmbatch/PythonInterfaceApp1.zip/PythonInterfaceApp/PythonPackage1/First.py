def Calculate(num1,num2,num3):
    return num1+num2+num3

MydataList=[]

